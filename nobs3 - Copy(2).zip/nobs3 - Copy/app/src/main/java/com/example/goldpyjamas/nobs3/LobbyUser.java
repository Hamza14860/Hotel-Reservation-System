package com.example.goldpyjamas.nobs3;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.TextView;

import android.support.design.widget.CoordinatorLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.ActionBar;



public class LobbyUser extends AppCompatActivity {

    private TextView mTextMessage;



    private ActionBar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lobby_user);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar2);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setTitle("USER LOBBY");


        //toolbar = getSupportActionBar();
        //toolbar.setTitle("User Lobby");
        ///////////////
        Intent intent = getIntent();
        User message = (User)intent.getSerializableExtra("loginDetails");
        System.out.println(message.getUsername()+" "+message.getPassword());
        //////////////


        System.out.println("AAAAA"+R.id.navigation_home);
        loadFragment(new HomeFragment());

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
    }
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Fragment fragment;
            switch (item.getItemId()) {
                case R.id.navigation_home   :
                    System.out.println("AAAAA"+R.id.navigation_home);

                    getSupportActionBar().setTitle("USER LOBBY ");
                    //toolbar.setTitle("Home");
                    fragment = new HomeFragment();

                    loadFragment(fragment);
                    return true;
                case R.id.navigation_Bookings:
                    System.out.println("AAAAA"+R.id.navigation_home);

                    getSupportActionBar().setTitle("MAKE RESERVATION");
                    //toolbar.setTitle("Bookings");
                    fragment = new BookingsFragment();
                    loadFragment(fragment);
                    return true;
                case R.id.navigation_account:
                    System.out.println("AAAAA"+R.id.navigation_home);

                    getSupportActionBar().setTitle("ACCOUNTS");
                    //toolbar.setTitle("Account");
                    fragment = new Accountfragment();
                    loadFragment(fragment);
                    return true;

            }

            return false;
        }
    };

    private void loadFragment(Fragment fragment) {
        // load fragment
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frame_container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }


}

/*package com.example.goldpyjamas.nobs3;

import android.os.Bundle;
import android.support.annotation.NonNull;

import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.TextView;

public class LobbyUser extends AppCompatActivity {

    private TextView mTextMessage;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lobby_user);

        mTextMessage = (TextView) findViewById(R.id.message);

    }

}*/

