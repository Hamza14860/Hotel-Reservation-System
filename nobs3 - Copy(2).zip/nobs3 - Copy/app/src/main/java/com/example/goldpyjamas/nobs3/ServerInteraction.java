package com.example.goldpyjamas.nobs3;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import java.io.*;
import java.net.Socket;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class ServerInteraction {



    ServerInteraction() throws ExecutionException, InterruptedException, IOException {



    }



    public  List<List<String>> getStringMessagesFromServer() throws ExecutionException, InterruptedException {


        class GetStringMessageFromServerTask extends AsyncTask<Void, Void, List<List<String>>> {


            GetStringMessageFromServerTask() {


            }

            @Override
            protected List<List<String>> doInBackground(Void ... params) {
                // TODO: attempt authentication against a network service.

                List<List<String>> gotList  = null;


                try {
                    Socket socket = SocketHandler.getSocket();


                    if (socket == null) {

                        return null;
                    }

                    ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
                    gotList = (List<List<String>>) ois.readObject();



                } catch (IOException e) {
                    e.printStackTrace();


                    return null;
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }


                return gotList;
            }

            @Override
            protected void onPostExecute(final List<List<String>> rcvMessage) {



            }

            @Override
            protected void onCancelled() {


            }
        }

        GetStringMessageFromServerTask gm = new GetStringMessageFromServerTask();
        List<List<String>> listrcv = gm.execute().get();

        return listrcv;
    }


    public  boolean sendStringMessageToServer(String message) throws InterruptedException, ExecutionException {
//        List<String> toSend = new ArrayList<String>();
//        toSend.add(message);
//
//        return sendStringMessagesToServer(toSend);
        class SendMessageToServerTask extends AsyncTask<String, Void, String> {



            SendMessageToServerTask() {


            }

            @Override
            protected String doInBackground(String... params) {
                // TODO: attempt authentication against a network service.




                try {

                    Socket socket = SocketHandler.getSocket();

                    if (socket == null) {

                        return "Error";
                    }
                    DataOutputStream dos = new DataOutputStream(socket.getOutputStream());

                    dos.writeUTF(params[0]);

                    Log.e("Socket getting", "not check");


                    return "0";
                } catch (IOException e) {
                    e.printStackTrace();


                    return "Error";
                }



            }

            @Override
            protected void onPostExecute(final String status) {


            }

            @Override
            protected void onCancelled() {


            }
        }


        SendMessageToServerTask sendMessageToServerTask  = new SendMessageToServerTask();
        String status = sendMessageToServerTask.execute(message).get();

        if (!status.equals("0")){
            return false;
        }
        return true;
    }

    public  boolean sendStringMessagesToServer(List<String> messages) throws ExecutionException, InterruptedException {






        class SendMessagesToServerTask extends AsyncTask<List<String>, Void, String> {



            SendMessagesToServerTask() {


            }

            @Override
            protected String doInBackground(List<String>... params) {
                // TODO: attempt authentication against a network service.




                try {
                    Socket socket = SocketHandler.getSocket();


                    if (socket == null) {

                        return "Error";
                    }
                    ObjectOutputStream dos = new ObjectOutputStream(socket.getOutputStream());

                    dos.writeObject(params[0]);


                    return "0";
                } catch (IOException e) {
                    e.printStackTrace();


                    return "Error";
                }



            }

            @Override
            protected void onPostExecute(final String status) {


            }

            @Override
            protected void onCancelled() {


            }
        }


        SendMessagesToServerTask sendMessagesToServerTask  = new SendMessagesToServerTask();
        String status = sendMessagesToServerTask.execute(messages).get();

        if (!status.equals("0")){
            return false;
        }
        return true;






    }


}
