package com.example.goldpyjamas.nobs3;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import org.w3c.dom.Text;

import java.net.Inet4Address;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {

    public List<Room> all_rows;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(View itemView, int position) throws ExecutionException, InterruptedException;
    }


    // Define the method that allows the parent activity or fragment to define the listener
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        // Your holder should contain a member variable
        // for any view that will be set as you render a row
        public TextView roomNo;
        public TextView roomType;
        public TextView roomCapacity;
        public TextView roomOcc;
        public TextView roomRent;


        Context context;

        // Define listener member variable




        // We also create a constructor that accepts the entire item row
        // and does the view lookups to find each subview
        public ViewHolder(Context c, final View itemView) {
                    // Stores the itemView in a public final member variable that can be used
                    // to access the context from any ViewHolder instance.
                    super(itemView);

                    roomNo = (TextView) itemView.findViewById(R.id.lblRoomNumber);
                    roomType =  (TextView) itemView.findViewById(R.id.lblRoomType);
                    roomCapacity =  (TextView) itemView.findViewById(R.id.lblCapacity);
                    roomOcc = (TextView) itemView.findViewById(R.id.lblOcc);
                    roomRent = (TextView) itemView.findViewById(R.id.lblRent);
                    this.context = c;

                    Button btnEdit = (Button) itemView.findViewById(R.id.btnEdit);

                    btnEdit.setOnClickListener(this);

        }

            @Override
            public void onClick(View v) {
                // Triggers click upwards to the adapter on click
                if (listener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        try {
                            listener.onItemClick(itemView, position);
                        } catch (ExecutionException e) {
                            e.printStackTrace();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }

                }


                //Log.e("AAAA", Integer.toString(1));


            }

    }

    // Provide a suitable constructor (depends on the kind of dataset)
    public MyAdapter(List<Room> all_rows_) {
        all_rows = all_rows_;
    }

    // Create new views (invoked by the layout manager)
    @Override
    public MyAdapter.ViewHolder onCreateViewHolder(ViewGroup parent,
                                                     int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);

        // Inflate the custom layout
        View contactView = inflater.inflate(R.layout.custom_row, parent, false);

        // Return a new holder instance
        ViewHolder viewHolder = new ViewHolder(null, contactView);

//        contactView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                int itemPosition = recyclerViewthindexOfChild(v);
//                //    Toast.makeText(MainActivity.this,"Selected item position is---"+ itemPosition,Toast.LENGTH_SHORT).show();
//                textView = (TextView)v.findViewById(R.id.number_textview);
//                Toast.makeText(MainActivity.this,"Selected val of clicked position is---"+ textView.getText().toString(),Toast.LENGTH_SHORT).show();
//            }
//        });


        return viewHolder;
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(MyAdapter.ViewHolder viewHolder, int position) {
        // Get the data model based on position


        // Set item views based on your views and data model
        TextView roomNumber = viewHolder.roomNo;
        TextView roomType  = viewHolder.roomType;

        TextView roomCap = viewHolder.roomCapacity;
        TextView roomOcc = viewHolder.roomOcc;
        TextView roomRent = viewHolder.roomRent;


        roomNumber.setText(all_rows.get(position).getRoomID());
        roomType.setText(all_rows.get(position).getRoomType());
        roomCap.setText(Integer.toString(all_rows.get(position).getCapacity()));
        roomOcc.setText(all_rows.get(position).getStatus());
        roomRent.setText(Long.toString(all_rows.get(position).getRentLong()));

        ;
    }

    // Returns the total count of items in the list
    @Override
    public int getItemCount() {
        return all_rows.size();
    }
}