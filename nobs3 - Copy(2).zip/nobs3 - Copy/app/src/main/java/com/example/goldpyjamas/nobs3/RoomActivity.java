package com.example.goldpyjamas.nobs3;


import android.app.AlertDialog;
import android.content.Context;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import android.support.v7.widget.Toolbar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class RoomActivity extends AppCompatActivity{

    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;
    private List<Room> rows = new ArrayList<Room>();


    public void loadRooms(Context c) throws ExecutionException, InterruptedException, IOException {


            rows.clear();

            ServerInteraction si = new ServerInteraction();

            si.sendStringMessageToServer("roomInfo");
            List<List<String>> gotList = si.getStringMessagesFromServer();


            //Log.w("a", gotList.toString());


            for (int i = 0; i < gotList.size(); ++i) {


                String roomNo = gotList.get(i).get(0);
                String type =  gotList.get(i).get(1);
                int cap=  Integer.parseInt(gotList.get(i).get(2));
                String occ = gotList.get(i).get(3);
                //Log.e("aiosfjoasijfoiasoiasjf", occ);
                long rent =  Long.parseLong(gotList.get(i).get(4));

                Room r = new Room(roomNo, type, cap, rent, occ);
                rows.add(r);



            }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_roomact, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.menuDeleteRoom:







                Intent intent = new Intent(this, AddRoomActivity.class);

                startActivity(intent);
                finish();

//                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
//                    alertDialogBuilder.setMessage(message)
//                            .setTitle("Operation Completed").setPositiveButton("OK", new DialogInterface.OnClickListener() {
//                        public void onClick(DialogInterface dialog, int id) {
//                            // FIRE ZE MISSILES!
//
//
//                            Intent intent = new Intent(c, RoomActivity.class);
//                            startActivity(intent);
//                            finish();
//                        }
//                    });
//
//                    AlertDialog alertDialog = alertDialogBuilder.create();
//                    alertDialog.show();



                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }



    public void sendRoomToEditRoomActivity(Room r){
        Intent intent = new Intent(this, EditRoomActivity.class);

        intent.putExtra("roomRow", r);
        startActivity(intent);


        finish();



    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        // check if the request code is same as what is passed  here it is 2
        if(requestCode==2)
        {
            //do the things u wanted
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {




        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setTitle("Room Management");



        recyclerView = (RecyclerView) findViewById(R.id.rcy_view);

        layoutManager =  new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
// specify an adapter (see also next example)


        try {
            loadRooms(this);



        }catch (Exception ex){
            ex.printStackTrace();
        }


////            String roomNo;
//            String type;
//            int cap;
//            String occ;
//            long rent;
//            while (allRoomInfo.next()){
//                roomNo = allRoomInfo.getString(1);
//                type = allRoomInfo.getString(2);
//                cap = Integer.parseInt(allRoomInfo.getString(3));
//
//                occ = allRoomInfo.getString(4);
//                rent = Long.parseLong(allRoomInfo.getString(5));
//
//                rows.add(new Room (roomNo, type, cap, rent, occ));
//
//            }
//



            mAdapter = new MyAdapter(rows);


            ((MyAdapter) mAdapter).setOnItemClickListener(new MyAdapter.OnItemClickListener() {
                @Override
                public void onItemClick(View itemView, int position) throws ExecutionException, InterruptedException {
                    Log.e("S", rows.get(position).toString());


                    Room r = rows.get(position);


                    sendRoomToEditRoomActivity(r);




                }
            });
            recyclerView.setAdapter(mAdapter);




        }

        //Socket socket = new Socket(MainActivity.serverIP, 8888);



}



