package com.example.goldpyjamas.nobs3;

import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Room implements Serializable {
    private String RoomID;

    public String getRoomID() {
        return RoomID;
    }

    public void setRoomID(String roomID) {
        RoomID = roomID;
    }

    public String getRoomType() {
        return RoomType;
    }

    public String getStatus(){
        return Occ;
    }



    public void setRoomType(String roomType) {
        RoomType = roomType;
    }

    public int getCapacity() {
        return Capacity;
    }

    public void setCapacity(int capacity) {
        Capacity = capacity;
    }


    public Long getRentLong() {
        return RentLong;
    }

    public void setRentLong(Long rentLong) {
        RentLong = rentLong;
    }

   private String RoomType;
    private int Capacity;

    private Long RentLong;
    private String Occ;

    public Room(String roomID, String roomType, int capacity, Long rentLong, String Occa) {
        RoomID = roomID;
        RoomType = roomType;
        Capacity = capacity;
        this.Occ = Occa;
        RentLong = rentLong;
    }
}
