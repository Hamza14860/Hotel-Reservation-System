package com.example.goldpyjamas.nobs3;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class EditRoomActivity extends AppCompatActivity {

    Room roomToChange;


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.menuDeleteRoom:

                ServerInteraction si = null;
                try {
                    si = new ServerInteraction();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    si.sendStringMessageToServer("deleteRoom");

                    si.sendStringMessageToServer(roomToChange.getRoomID());


                    final Context c = this;
                    String message = "Room " + roomToChange.getRoomID() + " deleted from the database.";
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
                    alertDialogBuilder.setMessage(message)
                            .setTitle("Operation Completed").setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            // FIRE ZE MISSILES!


                            Intent intent = new Intent(c, RoomActivity.class);
                            startActivity(intent);
                            finish();
                        }
                    });

                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();





                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }


                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {

        Intent intent = new Intent(this, RoomActivity.class);
        startActivity(intent);
        finish();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_room);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar2);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setTitle("Edit Room");


        roomToChange = (Room) getIntent().getSerializableExtra("roomRow");
//




        //Log.e("gotRoom",roomToChange.RoomID.toString() );

        EditText roomNo = (EditText) findViewById(R.id.txtRoomNo);
        EditText type = (EditText) findViewById(R.id.txtRoomType);
        EditText cap = (EditText) findViewById(R.id.txtCapacity);
        Switch occ = (Switch) findViewById(R.id.swOcc);
        EditText rent = (EditText) findViewById(R.id.txtRent);

        roomNo.setText(roomToChange.getRoomID());
        type.setText(roomToChange.getRoomType());
        cap.setText(Integer.toString(roomToChange.getCapacity()));
        if (roomToChange.getStatus().equals("Empty")){
            occ.setChecked(false);
        }else{
            occ.setChecked(true);
        }
        rent.setText(roomToChange.getRentLong().toString());
//        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });
    }
    public void btnOkClick(View view) throws ExecutionException, InterruptedException, IOException {
        EditText roomNo = (EditText) findViewById(R.id.txtRoomNo);
        EditText type = (EditText) findViewById(R.id.txtRoomType);
        EditText cap = (EditText) findViewById(R.id.txtCapacity);
        Switch occ = (Switch) findViewById(R.id.swOcc);
        EditText rent = (EditText) findViewById(R.id.txtRent);

        List<String> arr = new ArrayList<String>();






        arr.add(roomNo.getText().toString());
        arr.add(type.getText().toString());
        arr.add(cap.getText().toString());
        if (occ.isChecked()){
            arr.add("Occupied");

        }else{
            arr.add("Empty");
        }
        arr.add(rent.getText().toString());
        arr.add(roomToChange.getRoomID());



        ServerInteraction si = new ServerInteraction();



        si.sendStringMessageToServer("changeRoomInfo");


        si.sendStringMessagesToServer(arr);


        Intent intent = new Intent(this, RoomActivity.class);
        startActivity(intent);

        finish();



    }

}

