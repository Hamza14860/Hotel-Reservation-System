package com.example.goldpyjamas.nobs3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class AddRoomActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_room);
    }

    public void btnOkClick(View view) throws ExecutionException, InterruptedException, IOException {
        EditText roomNo = (EditText) findViewById(R.id.txtRoomNo);
        EditText type = (EditText) findViewById(R.id.txtRoomType);
        EditText cap = (EditText) findViewById(R.id.txtCapacity);
        Switch occ = (Switch) findViewById(R.id.swOcc);
        EditText rent = (EditText) findViewById(R.id.txtRent);

        List<String> arr = new ArrayList<String>();




        arr.add(roomNo.getText().toString());
        arr.add(type.getText().toString());
        arr.add(cap.getText().toString());

        arr.add(rent.getText().toString());




        ServerInteraction si = new ServerInteraction();



        si.sendStringMessageToServer("addRoom");


        si.sendStringMessagesToServer(arr);


        Intent intent = new Intent(this, RoomActivity.class);
        startActivity(intent);

        finish();



    }


    @Override
    public void onBackPressed() {

        Intent intent = new Intent(this, RoomActivity.class);
        startActivity(intent);
        finish();

    }
}
